# AWS和其他公有云



|   名称   | AWS  | ALi  |      Azure      | GCP  |      |
| :------: | :--: | :--: | :-------------: | :--: | ---- |
| 计算实例 | EC2  | ECS  |     虚拟机      |      |      |
|   存储   |  S3  | OSS  |    Blob存储     |      |      |
|  数据库  | RDS  | RDS  | Azure Databases |      |      |
|   容器   | ECS  | ACS  | Service Fabric  |      |      |
| 编排服务 | EKS  | ACK  |       AKS       |      |      |
|          |      |      |                 |      |      |
|          |      |      |                 |      |      |
|          |      |      |                 |      |      |
|          |      |      |                 |      |      |

